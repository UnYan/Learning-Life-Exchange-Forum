package com.a.component;

public class test extends v{
    int i ;
    private static final  String s = "taobao";
//    public test(int i){this.i = i;}
    public void foo(double d,float f){
        String s;
        final boolean b;
        class inner{
            void method(){
                System.out.println("i");
            }
        }
    }
    public static void main(String[] args) {
        test x = new test();
        x.foo(123,123);
        System.out.println("x");
    }
//    static int x = 10;
//    static {x+=5;}
//
//    public static void main(String[] args) {
//        System.out.println(x);
//    }
//    static {x/=3;}
}

class v{
    private final void run(){
        System.out.println("v");
    }
}
//        test a = new test(),b;
//        a.run();
//        double d = 5.3E12;
//        byte bb = 433;
//        float f = 11.1;
//        String a = "tao";
//        char g='\r';
//        String b = "bao" ;
//        String c = "taobao";
//        String d = "taobao";
//        String e = new String();
//        String f = new String();
//        System.out.println((a+b)==s);
//        System.out.println(c==s);
//        System.out.println(d==c);
//        System.out.println("e"+e==f);
//        byte i = 128;
//        float f = 42.0f;
//        float f1[] = new float[2];
//        float f2[] = new float[2];
//        float[] f3  = f1;
//        long x = 42;
//        f1[0] = 42.0f;
//        System.out.println(x == f1[0]);
//        System.out.println(f1==f2);
//        System.out.println(f1==f3);
//        int a[][] = new int[][3];